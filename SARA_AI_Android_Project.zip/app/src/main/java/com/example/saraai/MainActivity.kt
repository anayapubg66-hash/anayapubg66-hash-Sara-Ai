package com.example.saraai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private var tts: TextToSpeech? = null
    private val requestCodeAudio = 100
    private val requestCodeContacts = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 40)
        }
        val title = TextView(this).apply {
            text = "SARA AI"
            textSize = 30f
        }
        status = TextView(this).apply {
            text = "Assalam-o-alaikum! Main Sara hoon. Neeche button dabayein aur baat karein."
            textSize = 18f
            setPadding(0, 30, 0, 30)
        }
        listenButton = Button(this).apply {
            text = "Baat suno"
            setOnClickListener { startListening() }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(listenButton)
        setContentView(layout)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCodeAudio)
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val ur = tts?.setLanguage(Locale("ur", "PK"))
            if (ur == TextToSpeech.LANG_MISSING_DATA || ur == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("ur"))
            }
        }
    }

    private fun speak(message: String) {
        status.text = message
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "sara_reply")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCodeAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Sara ko apna hukm batayein")
        }
        try {
            startActivityForResult(intent, 200)
        } catch (_: Exception) {
            speak("Voice recognition service available nahi hai. Internet aur Google app ki settings check karein.")
        }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).trim()
        status.text = "Aap ne kaha: $raw"

        if (command.contains("sara") && (command.contains("baat suno") || command.contains("بات سنو"))) {
            speak("Ji, main sun rahi hoon. Batayein, kya karna hai?")
        } else if (command.contains("youtube") && (command.contains("kholo") || command.contains("open"))) {
            val launch = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            if (launch != null) {
                startActivity(launch)
                speak("YouTube khol rahi hoon.")
            } else speak("YouTube is phone mein install nahi hai.")
        } else if (command.contains("message") || command.contains("paigham") || command.contains("پیغام")) {
            speak("Message bhejne ka feature agle version mein contacts ke saath jora jayega. Filhal aap apna hukm dobara bol sakte hain.")
        } else {
            speak("Maaf kijiye, yeh hukm abhi mere pehle version mein shamil nahi. Mazeed hukm jald shamil honge.")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
